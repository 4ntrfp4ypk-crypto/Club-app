const tg = window.Telegram?.WebApp;
tg?.ready(); tg?.expand();
const $ = id => document.getElementById(id);
let initData = tg?.initData || "";
let me = null;
async function api(url, options={}) {
  const res = await fetch(url, { ...options, headers: { "Content-Type":"application/json", "X-Telegram-Init-Data":initData, ...(options.headers||{}) }});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || `Ошибка ${res.status}`);
  return data;
}
function toast(s){$("toast").textContent=s;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",2600)}
function show(id){$(id).classList.remove("hidden")}
async function load(){
 try {
  const d=await api("/api/me"); me=d; 
  if(d.player){show("profile");$("myNick").textContent=d.player.nickname;$("myPoints").textContent=d.player.points; }
  else show("register");
  if(d.isAdmin){show("admin");await loadAdmin();}
  await loadBoard(); await loadEvents();
 } catch(e){ $("register").classList.remove("hidden"); $("registerMsg").textContent = tg?.initData ? e.message : "Откройте эту Mini App через Telegram. Для локального просмотра включите DEV_MODE только на своём компьютере."; }
}
async function loadBoard(){const d=await api("/api/leaderboard");$("leaderboard").innerHTML=d.players.length?d.players.map((p,i)=>`<div class="entry"><span>${i+1}. ${esc(p.nickname)}</span><strong>${p.points}</strong></div>`).join(""):"Пока игроков нет";}
async function loadEvents(){const d=await api("/api/events");$("events").innerHTML=d.events.length?d.events.map(e=>`<div class="entry"><span><b>${esc(e.title)}</b><br><small class="muted">${new Date(e.starts_at).toLocaleString("ru-RU")}</small><br><small class="muted">${esc(e.description)}</small></span></div>`).join(""):"Мероприятия пока не запланированы.";}
async function loadAdmin(){const d=await api("/api/admin/players");$("playerSelect").innerHTML=d.players.map(p=>`<option value="${esc(p.telegram_id)}">${esc(p.nickname)} · ${p.points}</option>`).join("");const h=await api("/api/admin/history");$("history").innerHTML=h.history.length?h.history.map(x=>`<div class="entry"><span>${esc(x.nickname||x.telegram_id)}<br><small class="muted">${esc(x.note)} · ${esc(x.created_at)}</small></span><strong>${x.delta>0?"+":""}${x.delta} → ${x.balance_after}</strong></div>`).join(""):"Изменений пока нет.";}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("registerBtn").onclick=async()=>{try{await api("/api/register",{method:"POST",body:JSON.stringify({nickname:$("nickname").value})});toast("Профиль создан");location.reload();}catch(e){$("registerMsg").textContent=e.message;}};
$("savePoints").onclick=async()=>{try{await api("/api/admin/points",{method:"POST",body:JSON.stringify({telegram_id:$("playerSelect").value,mode:$("pointMode").value,amount:Number($("pointAmount").value),note:$("pointNote").value})});$("adminMsg").textContent="Изменения сохранены.";await load();}catch(e){$("adminMsg").textContent=e.message;}};
$("addEvent").onclick=async()=>{try{await api("/api/admin/events",{method:"POST",body:JSON.stringify({title:$("eventTitle").value,starts_at:$("eventDate").value,description:$("eventDesc").value})});toast("Мероприятие добавлено");await loadEvents();}catch(e){toast(e.message);}};
load();
