const express = require("express");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = Number(process.env.PORT || 3000);
const DEV_MODE = process.env.DEV_MODE === "true";
const ADMIN_ID = String(process.env.ADMIN_TELEGRAM_ID || "").trim();
const BOT_TOKEN = process.env.BOT_TOKEN || "";
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "poker-club.sqlite");

if (!DEV_MODE && !BOT_TOKEN) {
  console.warn("BOT_TOKEN is not set. Telegram Mini App API requests will be rejected.");
}
if (!DEV_MODE && !/^\d+$/.test(ADMIN_ID)) {
  console.warn("ADMIN_TELEGRAM_ID must be a numeric Telegram user ID.");
}

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS players (
  telegram_id TEXT PRIMARY KEY,
  nickname TEXT NOT NULL UNIQUE COLLATE NOCASE,
  first_name TEXT NOT NULL DEFAULT '',
  photo_url TEXT NOT NULL DEFAULT '',
  points INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS point_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id TEXT NOT NULL,
  delta INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  admin_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  starts_at TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

function verifyInitData(initData) {
  if (DEV_MODE && !initData) return { id: "dev-admin", first_name: "Demo" };
  if (!BOT_TOKEN || !initData) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;
  params.delete("hash");
  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`).join("\n");
  const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const calculated = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
  const a = Buffer.from(calculated, "hex");
  const b = Buffer.from(hash, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || Math.abs(Date.now() / 1000 - authDate) > 86400) return null;
  try {
    return JSON.parse(params.get("user") || "{}");
  } catch {
    return null;
  }
}

function auth(req, res, next) {
  const user = verifyInitData(req.get("X-Telegram-Init-Data") || "");
  if (!user || !user.id) return res.status(401).json({ error: "Откройте приложение через Telegram." });
  req.user = user;
  next();
}
function isAdmin(req) {
  return DEV_MODE || (ADMIN_ID && String(req.user.id) === ADMIN_ID);
}
function cleanNickname(value) {
  return String(value || "").trim().replace(/\s+/g, " ");
}

app.get("/health", (_req, res) => res.json({ ok: true }));
app.get("/api/me", auth, (req, res) => {
  const u = req.user;
  const existing = db.prepare("SELECT * FROM players WHERE telegram_id=?").get(String(u.id));
  res.json({ user: { id: String(u.id), first_name: u.first_name || "" }, player: existing || null, isAdmin: isAdmin(req) });
});
app.post("/api/register", auth, (req, res) => {
  const nickname = cleanNickname(req.body.nickname);
  if (nickname.length < 3 || nickname.length > 20 || !/^[\p{L}\p{N}_ -]+$/u.test(nickname)) {
    return res.status(400).json({ error: "Ник должен содержать 3–20 букв, цифр, пробелов, дефисов или _." });
  }
  const userId = String(req.user.id);
  try {
    db.prepare(`INSERT INTO players (telegram_id,nickname,first_name,photo_url)
      VALUES (?,?,?,?)
      ON CONFLICT(telegram_id) DO UPDATE SET first_name=excluded.first_name, photo_url=excluded.photo_url`)
      .run(userId, nickname, req.user.first_name || "", req.user.photo_url || "");
    res.json({ ok: true });
  } catch (e) {
    if (String(e.code).includes("CONSTRAINT")) return res.status(409).json({ error: "Этот ник уже занят. Выберите другой." });
    res.status(500).json({ error: "Не удалось сохранить регистрацию." });
  }
});
app.get("/api/leaderboard", auth, (_req, res) => {
  const rows = db.prepare("SELECT nickname, points FROM players ORDER BY points DESC, nickname COLLATE NOCASE ASC LIMIT 100").all();
  res.json({ players: rows });
});
app.get("/api/events", auth, (_req, res) => {
  res.json({ events: db.prepare("SELECT id,title,starts_at,description FROM events WHERE starts_at >= datetime('now','-1 day') ORDER BY starts_at ASC LIMIT 50").all() });
});
app.get("/api/admin/players", auth, (req, res) => {
  if (!isAdmin(req)) return res.sendStatus(403);
  res.json({ players: db.prepare("SELECT telegram_id,nickname,points FROM players ORDER BY nickname COLLATE NOCASE").all() });
});
app.get("/api/admin/history", auth, (req, res) => {
  if (!isAdmin(req)) return res.sendStatus(403);
  res.json({ history: db.prepare(`SELECT h.*,p.nickname FROM point_history h
    LEFT JOIN players p ON p.telegram_id=h.telegram_id ORDER BY h.id DESC LIMIT 100`).all() });
});
app.post("/api/admin/points", auth, (req, res) => {
  if (!isAdmin(req)) return res.sendStatus(403);
  const { telegram_id, mode, amount, note } = req.body || {};
  const player = db.prepare("SELECT * FROM players WHERE telegram_id=?").get(String(telegram_id || ""));
  const n = Number(amount);
  if (!player || !Number.isSafeInteger(n) || n < 0 || n > 1000000 || !["set","add","subtract"].includes(mode)) {
    return res.status(400).json({ error: "Проверьте игрока, режим и количество очков." });
  }
  const next = mode === "set" ? n : mode === "add" ? player.points + n : player.points - n;
  if (next < 0 || next > 10000000) return res.status(400).json({ error: "Итоговое количество очков вне допустимого диапазона." });
  const delta = next - player.points;
  const tx = db.transaction(() => {
    db.prepare("UPDATE players SET points=? WHERE telegram_id=?").run(next, player.telegram_id);
    db.prepare("INSERT INTO point_history (telegram_id,delta,balance_after,note,admin_id) VALUES (?,?,?,?,?)")
      .run(player.telegram_id, delta, next, String(note || "").slice(0,160), String(req.user.id));
  });
  tx();
  res.json({ ok: true, points: next });
});
app.post("/api/admin/events", auth, (req, res) => {
  if (!isAdmin(req)) return res.sendStatus(403);
  const title = String(req.body.title || "").trim().slice(0,80);
  const starts = String(req.body.starts_at || "").trim();
  const description = String(req.body.description || "").trim().slice(0,500);
  if (!title || !starts || Number.isNaN(Date.parse(starts))) return res.status(400).json({ error: "Укажите название и корректную дату." });
  db.prepare("INSERT INTO events (title,starts_at,description) VALUES (?,?,?)").run(title, new Date(starts).toISOString(), description);
  res.json({ ok: true });
});
app.delete("/api/admin/events/:id", auth, (req, res) => {
  if (!isAdmin(req)) return res.sendStatus(403);
  db.prepare("DELETE FROM events WHERE id=?").run(Number(req.params.id));
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`POKER CLUB listening on ${PORT}`));
